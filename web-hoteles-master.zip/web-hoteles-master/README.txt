Cargar el proyecto

1. tener instalado node
2. ejecutar el comando npm install
3. ejecutar el comando npm start
4. ingresar al navegador a la url http://localhost:8085